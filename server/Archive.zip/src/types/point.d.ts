export type TPoint = {
    x: number;
    y: number
}
