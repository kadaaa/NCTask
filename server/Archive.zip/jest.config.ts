export default {
    preset: 'ts-jest',
    transform: {},
}